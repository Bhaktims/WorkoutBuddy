
const jwt = require('jsonwebtoken');

const UserModel = require('../models/userModel');
const { response } = require('express');

const requireAuth = async(req,res,next)=>{
    
    const {authorization} = req.headers;

    if(!authorization){
        return res.status(401).json({error:'authorization token is required'})
    }
    //authorization = 'email','token'
    const token = authorization.split(' ')[1];
    try{
      const {_id}= jwt.verify(token,process.env.SECRET_CODE); 
      req.user = await UserModel.findOne({_id}).select('_id');
      next();
    }catch(err){
        res.status(401).json({error:"Request is not Authorised"});
    }
    
}

module.exports = requireAuth;