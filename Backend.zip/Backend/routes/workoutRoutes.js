const express = require('express');
const router = express.Router();
const {CreateWorkout,GetWorkouts,GetWorkout,DeleteWorkout,UpdateWorkout} = require('../controller/workoutController');
const requireAuth = require('../middleware/requireAuth');


router.use(requireAuth);

router.get('/',GetWorkouts)
router.get('/:id',GetWorkout)

router.post('/',CreateWorkout)

router.patch('/:id',UpdateWorkout)
router.delete('/:id',DeleteWorkout)

module.exports = router;
