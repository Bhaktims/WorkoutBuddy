import React, { useEffect } from 'react'
import WorkoutDetails from './components/WorkoutDetails';
import WorkoutForm from './components/WorkoutForm';
import useWorkoutContext from './hooks/useWorkoutContext';
import useAuthContext from './hooks/useAuthContext';

const Home = () => {
    // const [workouts,setWorkouts] = useState(null);
    const {workouts,dispatch} = useWorkoutContext()
    const {user} = useAuthContext();
    
    useEffect(()=>{
        const fetchWorkouts=async()=>{   
            const response = await fetch('/workout/',{
              headers:{
                'Authorization' :`Bearer ${user.token}`
              }
            });  
            // console.log(await response.text())
            const json = await response.json();//json extract json info from response object
            console.log(json);

            if ( response.ok ){
                dispatch({type:'SET_WORKOUTS',payload:json.workouts});// array of workout objects ( get all workouts) from controller class
            }
        }
        if(user){
          fetchWorkouts();  
        }
    },[dispatch,user]);
  return (
    <div>
      <div className='home'>
        <div className='workouts'>
            {workouts && workouts.map((workout)=>{
                return (
                   <WorkoutDetails key={workout._id} workout ={workout}/>
                )
            })}
        </div>
        <WorkoutForm/>
      </div>
    </div>
  )
}

export default Home
