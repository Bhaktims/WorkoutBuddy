import './App.css';
import { Routes,Route,BrowserRouter,Navigate} from 'react-router-dom';
import Home from './Home';
import Navbar from './components/Navbar';
import Login from './pages/login';
import Signup from './pages/Signup';
import useAuthContext from './hooks/useAuthContext';

function App() {
  const {user} = useAuthContext();
  return (
    <div>
      <BrowserRouter>
        <Navbar></Navbar>
          <div className="pages">
             <Routes>
               <Route path='/' element={user?<Home/>:<Navigate to ='/login'></Navigate>}> </Route>
               <Route path='/login' element={!user?<Login/>:<Navigate to='/'></Navigate>}> </Route>   
               <Route path='/signup' element={!user?<Signup/>:<Navigate to='/'></Navigate>}> </Route>
             </Routes>
          </div>
      </BrowserRouter>
    </div>
  );
}

export default App;
