import React, { useState } from 'react';
// import formatDistanceToNow from 'date-fns/formatDistanceToNow';
import useWorkoutContext from '../hooks/useWorkoutContext';
import UpdateForm from './UpdateForm';
import useAuthContext from '../hooks/useAuthContext';

const WorkoutDetails = ({workout}) => {

  const [updateData,setUpdateData] = useState('')
  const [show,setShow] = useState(false);

  const {dispatch} = useWorkoutContext();
 
  const {user} = useAuthContext();   

  const handleClick=async()=>{
    if(!user){
         return;
    }
      const response = await fetch('/workout/'+ workout._id,{
      method:'DELETE',
      headers:{'Authorization' :`Bearer ${user.token}`}
    });
     const json = await response.json();
     console.log(json)
     if(response.ok){
         dispatch ({type:'DELETE_WORKOUT',payload:json.workout})  
     }
   }

   const handlUpdate=()=>{
     setUpdateData(workout);
     setShow(!show);
   }
  return (
    <div className='workout-details'>
     <h2>{workout.title}</h2>
     <p>Load(kg) : {workout.load}</p> 
     <p>Reps : {workout.reps}</p> 
     <p>{workout.createdAt}</p>
     <span className="material-symbols-outlined" onClick={handlUpdate}>Edit &nbsp;</span>
     {/* <p>{formatDistanceToNow(new Date(workout.createdAt),{addSuffix:true})}</p> */}
     <span className="material-symbols-outlined" onClick={handleClick}>
      delete
      </span>

      {show && <UpdateForm updateData={updateData}></UpdateForm> }   
    </div>
  )
}

export default WorkoutDetails
