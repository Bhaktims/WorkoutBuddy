import React, { useState } from 'react'
import useWorkoutContext from '../hooks/useWorkoutContext'
import useAuthContext from '../hooks/useAuthContext';


const UpdateForm = ({updateData}) => {

    const {dispatch} = useWorkoutContext();    
    const{title,reps,load} = updateData;
    const [uTitle,setUTitle] = useState(title);
    const [uReps,setUReps] = useState(reps);
    const [uLoad,setULoad] = useState(load);
    const [error,setError] = useState('')
    const [show,setShow] = useState(true);
    const [success,setSuccess] = useState(false);

    const {user} = useAuthContext();

    const handleSubmit=async(e)=>{
       e.preventDefault();
       if(!user){
        setError('You must be logged in !!!');
        return
       }
       var workout={title:uTitle,reps:uReps,load:uLoad};
       const response = await fetch('/workout/'+ updateData._id,{
        method:'PATCH',
        body:JSON.stringify(workout),
        Headers:{
            'content-type':"application/json",
            'Authorization' :`Bearer ${user.token}`
        }
       });

       const json = await response.json();
       if(response.ok){
        setUTitle('');
        setUReps('');
        setULoad('');
        setShow(!show);
        setTimeout(()=>{
            setSuccess(true);
            setTimeout(()=>{
                setSuccess(false);
                setTimeout(()=>{
                    dispatch({type:'UPDATE_WORKOUT',payload:Object.assign(updateData,workout)})          
                },200)
            },1500)
        },500)
        
       }

       if(!response.ok) {
         setError(json.error);
       }
    }

    return (
    
    <>
      {success && <div> New Data Updated </div>}
     {show && <form className='create'onSubmit={handleSubmit}>
      <h3> UPDATE FORM </h3>  
      <label> Exercise Title :  </label> 
      <input type='text' value={uTitle} onChange={(e)=>{setUTitle(e.target.value)}}/>

      <label> Exercise Reps :  </label> 
      <input type='number' value={uReps} onChange={(e)=>{setUReps(e.target.value)}}/>

      <label> Exercise Load in KG : </label> 
      <input type='number' value={uLoad} onChange={(e)=>{setULoad(e.target.value)}}/>

      <button type='submit'> UPDATE EXERCISE </button> 
      {error && <div className='error'>{error}</div>}

    </form>
    }
    
    </>
  )
}

export default UpdateForm
