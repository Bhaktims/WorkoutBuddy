import React from 'react'
import { Link } from 'react-router-dom'
import { useLogout } from '../hooks/useLogout'
import useAuthContext from '../hooks/useAuthContext';


const Navbar = () => {
  const {logout}=useLogout();
  const{user} = useAuthContext();
  const handleClick=()=>{
    logout()
  }

  return (
   <header>
    <div className='container'>
        <Link to ="/"><b>WORK OUT BUDDY APP</b></Link>
        <nav>
           {user && (
           <div> 
          <span>{user.email}</span>
          <button onClick={handleClick}>Logout</button>&nbsp;  
          </div>
           )}
           {!user && (
           <div> 
           <button><Link to ="/login" >Login</Link></button>&nbsp;
           <button><Link to ="/signup">Signup</Link></button>
           </div>
           )}
          
        </nav>
    </div>
   </header>
  )
}

export default Navbar
